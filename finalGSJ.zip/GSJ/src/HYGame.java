import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.util.*;
import javax.imageio.ImageIO;
import javax.swing.*;

public class HYGame extends JPanel implements ActionListener{
	private int WIDTH = 1200;
	private int speed;
	private int width =15;
	private int height =80;
	private int life = 3;
	private Random random;
	
	Image img;
	File path = new File("./src\\background.jpg");
	JLabel life1 = new JLabel();
	JLabel life2 = new JLabel();
	JLabel life3 = new JLabel();
	ImageIcon lifeimg;
	Human human;
	Rectangle dw;
	
	int cnt = 0;
	int dwheight = 800;
	int ITEM_NUM = 10;

	public ArrayList <Item> oItem; //jungah : Item ArrayList
	public ArrayList <Color> c = new ArrayList<Color>();
	public static Color[] collist = {Color.BLACK,Color.BLACK,Color.BLACK,Color.decode("#FFF900"), Color.decode("#00FF7B"),Color.decode("#A900FF"),Color.decode("#FF4800"),Color.decode("#00FFFB")};

	class Point{
		int x1,x2,y1,y2;
		public Point(Rectangle rect) {
			this.x1 = rect.x;
			this.x2 = rect.width + this.x1;
			this.y1 = rect.y;
			this.y2 = this.y1 + rect.height;
		}
		
		public Point(Human human) {
			this.x1 = human.getX();
			this.x2 = this.x1 + human.width;
			this.y1 = human.getY();
			this.y2 = this.y1+ human.height;
		}
	}
	
	Point human_p;		//jungah : human point
	Point[] item_p;	//jungah : items point
	
	public HYGame() {
		
		try {
			life = 3;
			img = ImageIO.read(path);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		dw = new Rectangle();
		random =new Random() ;
		//jungah : Create human rect, items rect
		this.setLayout(null);
		this.setVisible(true);
		human = new Human();
		this.add(human);
		oItem = new ArrayList<Item>();
		speed = 30;
		
		lifeimg = new ImageIcon(this.getClass().getResource("bearlife.png"));
		life1.setIcon(lifeimg);	
		life2.setIcon(lifeimg);	
		life3.setIcon(lifeimg);	
		
		life1.setSize(100,100);
		life1.setLocation(0, 0);
		
		life2.setSize(100,100);
		life2.setLocation(50, 0);
		
		life3.setSize(100,100);
		life3.setLocation(100, 0);
	
		nextstage.scoreLabel.setText("SCORE : "+Human.score);
		nextstage.scoreLabel.setForeground(Color.WHITE);
		nextstage.scoreLabel.setFont(new Font("Arial",Font.BOLD,40));
		nextstage.scoreLabel.setSize(400, 50);
		nextstage.scoreLabel.setLocation(0, 100);
		
		this.add(nextstage.scoreLabel);
		this.add(life1);
		this.add(life2);
		this.add(life3);
		
		addItem();
	}
	
	public void addItem() {
		//jungah : randomly create Item rectangle
		int Width =width;
		int Height=height;
		
		for(int i = 0; i<ITEM_NUM;i++) {
			int positionx = random.nextInt(this.WIDTH);
			int positiony = - random.nextInt(1000);
			c.add(collist[random.nextInt(collist.length-1)]);
			oItem.add(new Item(c.get(c.size()-1), positionx, positiony, Width, Height));
		}
	}
	
	public void paintComponent(Graphics g) {
		if(life==0) 
			gameOver();
		else {
			human.requestFocus();
			super.paintComponent(g);
			cnt++;
			g.drawImage(img, 0, 0, this);
			//g.setColor(Color.LIGHT_GRAY);
			g.fillRect(0, dwheight, 1200, 10000);
			for (int i = 0 ; i<oItem.size(); i++) {
				Rectangle rect = oItem.get(i).getr();
				g.setColor(oItem.get(i).c);
				g.fillRect(rect.x, rect.y, rect.width, rect.height);
				if(cnt % 250 == 0) {
	
					rect.y+=speed;
				}
			}
			if(oItem.size()<=5&&life!=0)
				addItem();
		}
		repaint();
	}
		
	public void actionPerformed(ActionEvent arg0) {
			if(life==0)
				gameOver();
			collisionDetection(human, oItem);
	}

	public void collisionDetection(Human human, ArrayList<Item> Item) {
		ArrayList<Rectangle> item = new ArrayList<Rectangle>();
		Rectangle[] item_arr = new Rectangle[item.size()];
		
		for(int i = 0 ; i <Item.size();i++) { 
			item.add(Item.get(i).getr());	//jungah : ArrayList -> Rectangle[]
			item_arr = (Rectangle[]) item.toArray(new Rectangle[0]);
		}
		//jungah : upper left (x1,y1), bottom right(x2,y2) save "class Point"
		human_p = new Point(human);		//jungah : human point
		item_p = new Point[item_arr.length];	//jungah : items point
		
		for (int i = 0; i<item_p.length; i++) 
			item_p[i] = new Point(item_arr[i]);
			
		for(int i = 0; i<item_p.length; i++)
		{
			//jungah : item detection
			if(((human_p.x1<item_p[i].x2)&&(item_p[i].x1<human_p.x2))&&
			((human_p.y1<item_p[i].y2)&&(item_p[i].y1<human_p.y2))) 
			{
				//jungah : detection true
				if(oItem.get(i).c == Color.BLACK) {
					this.remove(this.getComponentCount()-1);
					--life;
				}
				else {
					
				human.score += 10;
				nextstage.scoreLabel.setText("SCORE : "+Human.score);
					if(human.score%50==0) 
						speed+=5;			
				}
				item_p[i] = null;
				item_arr[i] = null;
				oItem.remove(i);
				continue;
			}
			else {
				if(item_p[i].y1 > 600) {
					item_p[i] = null;
					item_arr[i] = null;
					oItem.remove(i);
					continue;
				}
			}
		}
	}
	
	public void gameOver() {

		MainPage.gameover(human.score);
		oItem = null;
		human = null;
	
	}
}