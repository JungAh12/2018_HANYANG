import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;

public class about extends JPanel{
	static JLabel imageLabel = new JLabel();											
	static ImageIcon img;
	static JButton playbutton;
	private final int BUTTON_LOCATION_X = 480;
	private final int BUTTON_LOCATION_Y = 400;
	public about() {
			
		this.setLayout(null);
		ImageIcon replayimg = new ImageIcon(this.getClass().getResource("startB.jpg"));
		
		playbutton = new JButton(replayimg);
		playbutton.setOpaque(false);
		playbutton.setContentAreaFilled(false);
		playbutton.setBorderPainted(false);
		playbutton.setLocation(BUTTON_LOCATION_X, BUTTON_LOCATION_Y+100);
		playbutton.setSize(240, 40);
		playbutton.setVisible(true);
		playbutton.addActionListener(new ActionListener_gamestart());
		
		img = new ImageIcon(this.getClass().getResource("about.jpg"));
		imageLabel.setIcon(img);
		imageLabel.setVisible(true);
		imageLabel.setSize(1200,800);
		imageLabel.setLocation(0,0);

		this.setSize(1200,800);
		this.setLocation(0,0);
		this.setVisible(true);
		this.add(playbutton);
		this.add(imageLabel);
	
	}

	class ActionListener_gamestart implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			Human.score = 0;
			playbutton.setVisible(false);
			MainPage.stage1_start();
		}
	}
}


		