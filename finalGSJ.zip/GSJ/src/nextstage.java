import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import javax.swing.JLabel;

public class nextstage extends JPanel{
	static JLabel imageLabel = new JLabel();											
	static ImageIcon img;
	static JButton replaybutton;
	static JLabel scoreLabel = new JLabel();
	
	public nextstage() {
			
		this.setLayout(null);
		ImageIcon replayimg = new ImageIcon(this.getClass().getResource("replayB.jpg"));
	
		replaybutton = new JButton(replayimg);
		replaybutton.setOpaque(false);
		replaybutton.setContentAreaFilled(false);
		replaybutton.setBorderPainted(false);
		replaybutton.setLocation(100,550);
		replaybutton.setSize(100,40);
		replaybutton.setVisible(true);
		replaybutton.setBackground(Color.decode("#9baec2"));
		replaybutton.addActionListener(new ActionListener_gamestart());
		
		img = new ImageIcon(this.getClass().getResource("gameover.gif"));
		imageLabel.setIcon(img);
		imageLabel.setVisible(true);
		imageLabel.setSize(1200,800);
		imageLabel.setLocation(0,0);


		scoreLabel.setText("SCORE:"+Integer.toString(Human.score));
		scoreLabel.setSize(400,50);
		scoreLabel.setLocation(100, 500);
		scoreLabel.setFont(new Font("Arial",Font.BOLD,40));
		
		this.setSize(1200,800);
		this.setLocation(0,0);
		this.setVisible(true);
		this.add(scoreLabel);
		this.add(replaybutton);
		this.add(imageLabel);
		
	}
	
	/*----jungah : invisible img label function---*/
	public void setInvisible() {
		this.imageLabel.setVisible(false);
		img = null;
		imageLabel = null;		
	}

	class ActionListener_gamestart implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			Human.score = 0;
			replaybutton.setVisible(false);
			MainPage.stage1_start();
		}
	}
}


		