package game;
import java.awt.event.*;
import java.awt.*;
import java.awt.image.*;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.*;
public class work extends JPanel implements ActionListener {


	private int HEIGHT = 500;
	private int WIDTH = 700;
	private int space;
	private int speed;
	private int width =80;
	private int height =70;
	private Rectangle human;
	private Random random;
	private JLabel imageLabel = new JLabel();
										//양정아 : JLabel에 이미지 설정
	
	
	JLabel timerLabel = new JLabel();
	TimerThread th = new TimerThread(timerLabel);
	public Timer t;
	private ArrayList <Rectangle> ohuman;
	public work() {
	ImageIcon img = new ImageIcon(this.getClass().getResource("4.gif"));	//양정아 : 표시하고자 하는 이미지 아이콘 생성
	imageLabel.setIcon(img);		
		timerLabel.setFont(new Font("Gothic",Font.ITALIC,20));
		timerLabel.setLocation(0,0);
		timerLabel.setSize(50,30);
		timerLabel.setOpaque(true);
		timerLabel.setBackground(Color.LIGHT_GRAY);
		
		t = new Timer(20,this);
		random =new Random( ) ;
		ohuman = new ArrayList<Rectangle>();
		human = new Rectangle(WIDTH/2, HEIGHT-100, width, height);
		space =300;
		speed = 2;
		addhuman(true);
		
		
		this.add(timerLabel);

		this.add(imageLabel);
		t.start();
		th.start();
		

	}
	public void addhuman(boolean first) {
		int positionx=random.nextInt() %2;
		int x=0;
		int y =0;
		int Width =width;
		int Height=height;
		if(positionx==0) {
			x = Width/2;
			}
		else {
			x = Width/2+10;
		}
		if(first) {
			ohuman.add(new Rectangle(x, y, Width, Height));
		}
		else {
			ohuman.add(new Rectangle(x, x,Width, Height));
		}
	}
	public void paintComponent(Graphics g) {
		System.out.print("ssss");
		super.paintComponent(g);
		g.setColor(Color.MAGENTA);
		for (Rectangle rect:(ohuman)) {
			g.fillRect(rect.x, rect.y, rect.width, rect.height);
		}
	}
		
	public void actionPerformed(ActionEvent arg0) {		
		Rectangle rect;
		for (int i=0; i<ohuman.size(); i++) {
			rect = ohuman.get(i);
			rect.y += speed;
		}
	repaint();
	}
	
  }
class TimerThread extends Thread{
	private JLabel timerLabel;
	
	public TimerThread(JLabel timerLabel) {
		this.timerLabel = timerLabel;
	}
	
	@Override
	public void run() {
		double n=40;
		while(n>=0) {
			timerLabel.setText(Double.toString(n));
			n--;
			try {
				Thread.sleep(1000);
			}
			catch(InterruptedException e) {return;}
		}
	}
	
}



	

/**/